// Inline SVG icons — kept here so all resume content lives in one place
export const ICONS = {
  phone:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 16.92v3a2 2 0 0 1-2.18 2 19.79 19.79 0 0 1-8.63-3.07 19.5 19.5 0 0 1-6-6 19.79 19.79 0 0 1-3.07-8.67A2 2 0 0 1 4.11 2h3a2 2 0 0 1 2 1.72 12.84 12.84 0 0 0 .7 2.81 2 2 0 0 1-.45 2.11L8.09 9.91a16 16 0 0 0 6 6l1.27-1.27a2 2 0 0 1 2.11-.45 12.84 12.84 0 0 0 2.81.7A2 2 0 0 1 22 16.92z"/></svg>',
  mail:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/><polyline points="22,6 12,13 2,6"/></svg>',
  home:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/></svg>',
  github:
    '<svg viewBox="0 0 24 24" fill="currentColor" stroke="none"><path d="M12 .5C5.7.5.5 5.7.5 12c0 5.1 3.3 9.4 7.9 10.9.6.1.8-.3.8-.6v-2c-3.2.7-3.9-1.5-3.9-1.5-.5-1.3-1.3-1.7-1.3-1.7-1.1-.7.1-.7.1-.7 1.2.1 1.8 1.2 1.8 1.2 1 1.8 2.8 1.3 3.5 1 .1-.8.4-1.3.7-1.6-2.6-.3-5.3-1.3-5.3-5.7 0-1.3.5-2.3 1.2-3.1-.1-.3-.5-1.5.1-3.1 0 0 1-.3 3.3 1.2a11.5 11.5 0 0 1 6 0C17.3 4.7 18.3 5 18.3 5c.6 1.6.2 2.8.1 3.1.8.8 1.2 1.8 1.2 3.1 0 4.4-2.7 5.4-5.3 5.7.4.4.8 1.1.8 2.2v3.3c0 .3.2.7.8.6 4.6-1.5 7.9-5.8 7.9-10.9C23.5 5.7 18.3.5 12 .5z"/></svg>',
  link:
    '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"/><path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"/></svg>'
}

export const resumeData = {
  name: '蒋兴邦',
  position: '',
  avatar: '/avatar.png',
  contact: [
    { label: '电话', icon: 'phone', values: ['+86 177 2150 2232'] },
    { label: '邮箱', icon: 'mail', values: ['xingbangtech@qq.com','xingbangtech@gmail.com'] },
    { label: '住址', icon: 'home', values: ['南京市栖霞区仙鹤门2号路仙居雅苑33栋602室（502室上方阁楼）'] },
  ],
  skills: [
    { name: '1.', desc: '熟悉WPS、Office等基本办公软件：excel(VBA)、word、pdf; 熟悉钉钉、飞书、语雀等协作工具，尤其是多维表格的设计'},
    { name: '2.', desc: '熟悉Python、JavaScript等编程语言，能够实现简单自动化办公、小项目开发； 了解fastapi、vue3、vite、element-plus等库或工具' },
    { name: '3.', desc: '了解cpp、java、kotlin，pgsql、mysql、docker等，了解市面各大模型，能够借助AI不断学习' },
    { name: '4.', desc: '乐高相关：wedo2.0、EV3LAB、EV3classroom、LEGO STUDIO建模' },
    { name: '5.', desc: '创客相关：arduino、scratch、scratch-gui、中鸣robosim、优必选ucode、DFrobot的mindplus(含插件开发、竞赛方案设计)、乐鑫esp32-s3和idf、嘉立创系列、拓竹3D打印、sketchup和blender建模、激光切割等' },

  ],
  interests: ['技术写作', '旅游', '创客', '象棋', '游戏'],
  experience: [
    {
      date: '2018.04-2023.05',
      title: '讲师、教务、行政',
      sub: '南京思顿姆科技有限公司',
      desc: [
        '1. 讲师：主要负责中心45300、45544+45560等乐高主题系列课程',
        '2. 教务：教务系统管理，排课、录入等；教研，讲师技能培训等',
        '3. 行政：家长接待；员工团建；人社系统操作：用工参保、退工停保、申领补贴等',
        '4. 社团：招生宣传、报名收费统计、排课、授课（9686），配合校方开展相关活动以及准备台账材料等',
        '5. 竞赛：招募队员、组织集训、带队参赛；栖霞区区赛赞助、后勤保障等',
        '6. 其他：中心续费、社团转化；教育设备招投标；其他一切琐事'
      ]
    },
    {
      date: '2023.11-2023.12',
      title: '讲师',
      sub: '南京机御人工智能科技有限公司',
      desc: [
        '1.主要负责学校社团、校外竞赛集训等课程授课'
      ]
    },
    {
      date: '2024.09-2026.03',
      title: '运营、行政',
      sub: '南京吉才汇科技有限公司',
      desc: [
        '1.运营：统筹落实科小、高企、知产（软著、专利）等资质类项目申报；',
        '2.行政：档案归档、钉钉OA管理、人社系统操作等杂务',
        '3.业务：项目对接、谈判、合同拟定、签署等',
        '4.其他：利用钉钉多维表格从零建立起公司数字资产档案，方便员工查询，提高工作效率。'
      ]
    },
    {
      date: '2026.04-2026.06',
      title: '跨境电商运营',
      sub: '南京如成科技有限公司',
      desc: [
  
      ]
    // },
    // {
    //   date: '2020.09至今',
    //   title: '理事',
    //   sub: '南京市栖霞区致悦社区科技服务中心（民非）',
    //   desc: [
    //     '1.全流程注册办理，知晓民非双重（实际：科技局、民政局、行政审批局）监管，以及和企业的区别'
    //   ]
    // },
    // {
    //   date: '2025.12至今',
    //   title: '法人、董事、财务、股东',
    //   sub: '南京致悦科技有限公司',
    //   desc: [
    //     '1.学习公司运营知识，尤其财税实操'
    //   ]
    }
  ],
  projects: [
    // {
    //   name: '企业级低代码平台',
    //   tag: '2022 — 至今',
    //   desc: '面向运营人员的可视化搭建平台，支持拖拽编排、Schema 驱动渲染与多端导出；日均页面创建 3000+。',
    //   stack: 'Vue3, TypeScript, Vite, Node.js, MongoDB'
    // }
  ],
  education: [
    {
      date: '2015.09-2018.06',
      title: '汽车检测与维修技术（专科）',
      sub: '南京工业职业技术大学',
      desc: [
        '1. 专业课程内容涉及机械、电子等，期间参与一项创新训练项目——小型塑料瓶压缩打包一体机',
        '2. 分院学生会宣传部部长，校级新闻通讯员。期间推进了分院学生会部门合并，提高了办事效率；同时也积极参加校内外各种（公益）活动。',
        '3. 校数学建模协会学习部部长，给协会会员培训数学建模基础技能；期间接触了运筹学、博弈论等，学习了 lingo、matlab、python 等软件，参加竞赛并获得国家级数学建模一等奖（获奖率 1%左右）'
      ]
    },
    {
      date: '2026.01-2028.06（预计毕业时间）',
      title: '电子信息工程（本科、学士学位统考已过）',
      sub: '南京信息工程大学',
      desc: [
      ]
    }
  ]
}
